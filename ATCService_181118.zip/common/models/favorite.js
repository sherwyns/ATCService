'use strict';

module.exports = function(Favorite) {

};
