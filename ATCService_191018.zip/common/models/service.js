'use strict';

let disableMethods = require('../../server/disable-methods');

module.exports = function(Service) {
};
